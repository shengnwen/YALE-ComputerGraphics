document.write('<script type="text/javascript" src="../../chapter3/cube.js"></script>');
document.write('<script type="text/javascript" src="../../chapter3/cone.js"></script>');
document.write('<script type="text/javascript" src="../../chapter3/cylinder.js"></script>');
document.write('<script type="text/javascript" src="./circularstreet.js"></script>');