function NVMCClient() {
	}
