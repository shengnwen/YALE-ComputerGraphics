document.write('<script type="text/javascript" src="cube.js"></script>');
document.write('<script type="text/javascript" src="cone.js"></script>');
document.write('<script type="text/javascript" src="cylinder.js"></script>');
document.write('<script type="text/javascript" src="circularstreet.js"></script>');