document.write('<script type="text/javascript" src="../../chapter3/cube.js"></script>');
document.write('<script type="text/javascript" src="cylinder.js"></script>');
document.write('<script type="text/javascript" src="ring.js"></script>');
