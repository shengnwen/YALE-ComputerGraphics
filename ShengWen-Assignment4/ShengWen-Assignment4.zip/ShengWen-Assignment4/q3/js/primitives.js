document.write('<script type="text/javascript" src="js/b-spline.js"></script>');
document.write('<script type="text/javascript" src="js/b-spline-nurb.js"></script>');