document.write('<script type="text/javascript" src="js/cube-cone-cylinder.js"></script>');
document.write('<script type="text/javascript" src="js/tetrahedron.js"></script>');
document.write('<script type="text/javascript" src="js/sphere_latlong.js"></script>');
document.write('<script type="text/javascript" src="js/sphere_subd.js"></script>');
document.write('<script type="text/javascript" src="js/torus.js"></script>');